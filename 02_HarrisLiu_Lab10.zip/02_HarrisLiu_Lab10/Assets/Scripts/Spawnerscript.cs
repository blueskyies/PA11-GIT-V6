﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawnerscript : MonoBehaviour
{
    public GameObject SpawnObjectRed;
    public GameObject SpawnObjectBrown;
    public GameObject SpawnObjectGreen;
    float PositionY;

    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("SpawnObjectRedCube", 1, 3);
        InvokeRepeating("SpawnObjectBrownCube", 2.5f, 10);
        InvokeRepeating("SpawnObjectGreenCube", 5.3f, 5);
    }

    // Update is called once per frame
    void Update()
    {
       


    }

    void SpawnObjectRedCube()
    {
        PositionY = Random.Range(8, -8f);
        this.transform.position = new Vector3(transform.position.x, PositionY, transform.position.z);
        Instantiate(SpawnObjectRed, transform.position, transform.rotation);
    }
    void SpawnObjectBrownCube()
    {
        PositionY = Random.Range(4, -4f);
        this.transform.position = new Vector3(transform.position.x, PositionY, transform.position.z);
        Instantiate(SpawnObjectBrown, transform.position, transform.rotation);
    }
    void SpawnObjectGreenCube()
    {
        PositionY = Random.Range(6, -6f);
        this.transform.position = new Vector3(transform.position.x, PositionY, transform.position.z);
        Instantiate(SpawnObjectGreen, transform.position, transform.rotation);
    }
}
