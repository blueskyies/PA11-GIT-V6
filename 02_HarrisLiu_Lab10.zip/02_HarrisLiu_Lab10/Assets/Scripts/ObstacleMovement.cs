﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ObstacleMovement : MonoBehaviour
{
    private float xSpeed = -4f;
    public static float score = 0;
    public Text Scoretext;

    void Start()
    {
        Scoretext = GameObject.Find("ScoreText").GetComponent<Text>();
    }

    void Update()
    {
        transform.Translate(new Vector3(xSpeed * Time.deltaTime, 0, 0f));

        if (transform.position.x < -27)
        {
            ScoreUpdate();
            Destroy(this.gameObject);
        }
    }

    void ScoreUpdate()
    {
        score++;
        Scoretext.text = "Score: " + score;
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            SceneManager.LoadScene("LoseScene");
        }
    }
}
